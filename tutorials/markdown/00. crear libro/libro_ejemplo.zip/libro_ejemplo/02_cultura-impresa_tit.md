<p class="titulo-capitulo">CAPÍTULO 2</p>

## CULTURA IMPRESA

<figure>
    ![Barco con diagrama](imagenes/barco-capitulo2.png)
    <figcaption></figcaption>
</figure>
