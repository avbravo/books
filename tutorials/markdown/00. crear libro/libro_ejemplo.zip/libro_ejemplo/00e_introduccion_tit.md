## INTRODUCCIÓN

<figure>
    ![Un barco](imagenes/barco-sin-icono.png)
    <figcaption></figcaption>
</figure>

