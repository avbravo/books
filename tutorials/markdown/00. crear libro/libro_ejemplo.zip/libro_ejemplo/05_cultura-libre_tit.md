<p class="titulo-capitulo">CAPÍTULO 5</p>

## CULTURA LIBRE

<figure>
    ![Barco con símbolo de copyleft](imagenes/barco-capitulo5.png)
    <figcaption></figcaption>
</figure>

