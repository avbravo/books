convert portada.png  -density 124x127.5 portada.pdf || echo 'Es posible que tengas que cambiar la política de seguridad de ImageMagick (https://fluca1978.github.io/2020/06/03/ImageMagikPDF.html).'
