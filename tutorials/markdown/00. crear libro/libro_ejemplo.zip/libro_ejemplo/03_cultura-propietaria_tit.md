<p class="titulo-capitulo">CAPÍTULO 3</p>

## CULTURA PROPIETARIA

<figure>
    ![Barco con símbolo anticopyright](imagenes/barco-capitulo3.png)
    <figcaption></figcaption>
</figure>
