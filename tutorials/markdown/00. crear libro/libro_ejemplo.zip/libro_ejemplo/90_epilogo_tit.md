## EPÍLOGO

<figure>
    ![Barco con licencia Creative Commons BY-SA en la vela](imagenes/barco-epilogo.png)
    <figcaption></figcaption>
</figure>

