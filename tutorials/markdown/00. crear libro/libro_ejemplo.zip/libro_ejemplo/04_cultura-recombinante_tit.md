<p class="titulo-capitulo">CAPÍTULO 4</p>

## CULTURA RECOMBINANTE

<figure>
    ![Barco con icono parecido al del barco de The Pirate Bay](imagenes/barco-capitulo4.png)
    <figcaption></figcaption>
</figure>

