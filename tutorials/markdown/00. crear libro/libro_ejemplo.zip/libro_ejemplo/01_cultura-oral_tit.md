<p class="titulo-capitulo">CAPÍTULO 1</p>

## CULTURA ORAL

<figure>
    ![Barco con el símbolo del reciclaje](imagenes/barco-capitulo1.png)
    <figcaption></figcaption>
</figure>

