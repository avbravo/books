<p class="titulo-capitulo">CAPÍTULO 6</p>

## CULTURA COLECTIVA
<figure>
    ![Barco con símbolo de red](imagenes/barco-capitulo6.png)
    <figcaption></figcaption>
</figure>


